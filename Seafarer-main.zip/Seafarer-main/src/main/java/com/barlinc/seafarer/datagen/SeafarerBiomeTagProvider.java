package com.barlinc.seafarer.datagen;

import com.barlinc.seafarer.Seafarer;
import com.barlinc.seafarer.registry.tags.SeafarerBiomeTags;
import com.barlinc.seafarer.registry.SeafarerBiomes;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.BiomeTagsProvider;
import net.minecraft.tags.BiomeTags;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;

public class SeafarerBiomeTagProvider extends BiomeTagsProvider {

    public SeafarerBiomeTagProvider(PackOutput output, CompletableFuture<Provider> provider, ExistingFileHelper helper) {
        super(output, provider, Seafarer.MOD_ID, helper);
    }

    @Override
    protected void addTags(@NotNull Provider provider) {
        this.addTags();
    }

    protected void addTags() {

        this.tag(SeafarerBiomeTags.HAS_VOLCANOES).add(SeafarerBiomes.VOLCANIC_ISLAND);

        this.tag(BiomeTags.IS_OVERWORLD).add(
                SeafarerBiomes.VOLCANIC_ISLAND
        );
    }
}
